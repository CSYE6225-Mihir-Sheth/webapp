#!/bin/bash

sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get install unzip
sudo apt-get install nodejs npm -y
sudo mkdir opt
sudo mv /home/admin/webapp.zip /home/admin/opt/webapp.zip
sudo mv /home/admin/users.csv /home/admin/opt/webapp/users.csv
cd opt
sudo unzip -o webapp.zip
cd webapp
sudo npm i
sudo npm run test
sudo cp /home/admin/app.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable app.service
sudo systemctl start app.service
# sudo npm start